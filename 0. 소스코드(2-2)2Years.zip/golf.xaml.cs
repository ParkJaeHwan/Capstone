﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
//System.IDisposable;

using Microsoft.Kinect;
using Microsoft.Kinect.VisualGestureBuilder;

namespace KinectCapstone_Project
{
    public partial class golf : Window
    {
        KinectSensor kinect;

        // Color
        ColorFrameReader colorFrameReader;
        FrameDescription colorFrameDesc;
        ColorImageFormat colorFormat = ColorImageFormat.Bgra;

        // Body
        int BODY_COUNT;
        BodyFrameReader bodyFrameReader;
        Body[] bodies;
        float condidence1 = 0;
        int i = 0;
        // Gesture
        VisualGestureBuilderFrameReader[] gestureFrameReaders;
        IReadOnlyList<Gesture> gestures;
        bool _displayBody = false;
        // WPF
        WriteableBitmap colorBitmap;
        byte[] colorBuffer;
        int colorStride;
        MultiSourceFrameReader _reader;
        IList<Body> _bodies;
        Int32Rect colorRect;
        public static float confidence;
        public golf()
        {
            InitializeComponent();
        }
        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            main main = new main();
            main.Show();
            this.Close();

            System.Diagnostics.Process.Start(Application.ResourceAssembly.Location);
            Application.Current.Shutdown();
            GC.Collect(); //재시작
        }
        private void ButtonClicked2(object sender, RoutedEventArgs e)
        {
            golf_video golf_video = new golf_video();
            golf_video.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                kinect = KinectSensor.GetDefault();
                if (kinect == null)
                {
                    throw new Exception("Kinect를 열 수 없습니다.");
                }

                kinect.Open();
                _displayBody = !_displayBody;
                kinect = KinectSensor.GetDefault();

                if (kinect != null)
                {

                    _reader = kinect.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Depth | FrameSourceTypes.Infrared | FrameSourceTypes.Body);
                    _reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;
                }
                colorFrameDesc = kinect.ColorFrameSource.CreateFrameDescription(
                                                        colorFormat);

                colorFrameReader = kinect.ColorFrameSource.OpenReader();
                colorFrameReader.FrameArrived += colorFrameReader_FrameArrived;

                colorBitmap = new WriteableBitmap(
                                    colorFrameDesc.Width, colorFrameDesc.Height,
                                    96, 96, PixelFormats.Bgra32, null);
                colorStride = colorFrameDesc.Width * (int)colorFrameDesc.BytesPerPixel;
                colorRect = new Int32Rect(0, 0,
                                    colorFrameDesc.Width, colorFrameDesc.Height);
                colorBuffer = new byte[colorStride * colorFrameDesc.Height];
                ImageColor.Source = colorBitmap;

                BODY_COUNT = kinect.BodyFrameSource.BodyCount;

                bodies = new Body[BODY_COUNT];

                bodyFrameReader = kinect.BodyFrameSource.OpenReader();
                bodyFrameReader.FrameArrived += bodyFrameReader_FrameArrived;

                InitializeGesture();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Close();
            }
        }

        void colorFrameReader_FrameArrived(object sender, ColorFrameArrivedEventArgs e)
        {
            UpdateColorFrame(e);
            DrawColorFrame();
        }
        void UpdateColorFrame(ColorFrameArrivedEventArgs e)
        {
            using (var colorFrame = e.FrameReference.AcquireFrame())
            {
                if (colorFrame == null)
                {
                    return;
                }

                colorFrame.CopyConvertedFrameDataToArray(
                                            colorBuffer, colorFormat);
            }
        }
        private void DrawColorFrame()
        {
            colorBitmap.WritePixels(colorRect, colorBuffer, colorStride, 0);
        }
        void bodyFrameReader_FrameArrived(object sender, BodyFrameArrivedEventArgs e)
        {
            UpdateBodyFrame();
        }
        void InitializeGesture()
        {
            gestureFrameReaders = new VisualGestureBuilderFrameReader[BODY_COUNT];
            for (int count = 0; count < BODY_COUNT; count++)
            {
                VisualGestureBuilderFrameSource gestureFrameSource;
                gestureFrameSource = new VisualGestureBuilderFrameSource(kinect, 0);
                gestureFrameReaders[count] = gestureFrameSource.OpenReader();
                gestureFrameReaders[count].FrameArrived += gestureFrameReaders_FrameArrived;
            }

            VisualGestureBuilderDatabase gestureDatabase;
            gestureDatabase = new VisualGestureBuilderDatabase("golf.gbd");

            uint gestureCount;
            gestureCount = gestureDatabase.AvailableGesturesCount;
            gestures = gestureDatabase.AvailableGestures;
            for (int count = 0; count < BODY_COUNT; count++)
            {
                VisualGestureBuilderFrameSource gestureFrameSource;
                gestureFrameSource = gestureFrameReaders[count].VisualGestureBuilderFrameSource;
                gestureFrameSource.AddGestures(gestures);
                foreach (var g in gestures)
                {
                    gestureFrameSource.SetIsEnabled(g, true);
                }
            }
        }

        void gestureFrameReaders_FrameArrived(object sender, VisualGestureBuilderFrameArrivedEventArgs e)
        {
            VisualGestureBuilderFrame gestureFrame = e.FrameReference.AcquireFrame();
            if (gestureFrame == null)
            {
                return;
            }
            UpdateGestureFrame(gestureFrame);
            gestureFrame.Dispose();
        }
        void UpdateGestureFrame(VisualGestureBuilderFrame gestureFrame)
        {
            bool tracked;
            tracked = gestureFrame.IsTrackingIdValid;
            if (!tracked)
            {
                return;
            }
            foreach (var g in gestures)
            {
                result(gestureFrame, g);
            }
        }
        void result(VisualGestureBuilderFrame gestureFrame, Gesture gesture)
        {
            int count = GetIndexofGestureReader(gestureFrame);
            GestureType gestureType;
            gestureType = gesture.GestureType;
            switch (gestureType)
            {
                case GestureType.Discrete:
                    DiscreteGestureResult dGestureResult;
                    dGestureResult = gestureFrame.DiscreteGestureResults[gesture];

                    bool detected;
                    detected = dGestureResult.Detected;
                    if (!detected)
                    {

                    }
                    confidence = dGestureResult.Confidence;


                    if (confidence > 0.005)
                    {

                        GetTextBlock(1).Text = "바른 자세입니다";

                        //GetTextBlock(2).Text;
                        //condidence1 = confidence + condidence1;
                        //   string discrete = gesture2string(gesture) + " : Detected (" + confidence.ToString() + ")";
                        // GetTextBlock(2).Text = discrete;
                        //string discrete1 = gesture2string(gesture) + " : Detected (" + condidence1.ToString() + ")";
                        //GetTextBlock(3).Text = discrete1;
                        //if (condidence1 > 25.8)
                        //{
                        //i++;
                        // GetTextBlock(3).Text = "i";
                        //  string discrete2 = gesture2string(gesture) + " : Detected (" + i.ToString() + ")";
                        //GetTextBlock(4).Text = discrete2;
                        //condidence1 = 0;
                        //}

                    }
                    else
                    {
                        GetTextBlock(1).Text = "잘못된 자세입니다.";

                    }


                    break;

                case GestureType.Continuous:
                    ContinuousGestureResult cGestureResult;
                    cGestureResult = gestureFrame.ContinuousGestureResults[gesture];

                    float progress;
                    progress = cGestureResult.Progress;
                    string continuous = gesture2string(gesture)
                            + " : Progress " + progress.ToString();
                    GetTextBlock(count).Text = continuous;
                    break;
                default:
                    break;
            }
        }
        TextBlock GetTextBlock(int index)
        {
            switch (index)
            {
                case 1:
                    return TextBlock1;
                case 2:
                    return TextBlock2;
                case 3:
                    return TextBlock3;
                case 4:
                    return TextBlock4;
                case 5:
                    return TextBlock5;
                default:
                    return TextBlock6;

            }
        }
        string gesture2string(Gesture gesture)
        {
            return gesture.Name.Trim();
        }
        int GetIndexofGestureReader(VisualGestureBuilderFrame gestureFrame)
        {
            for (int index = 0; index < BODY_COUNT; index++)
            {
                if (gestureFrame.TrackingId
                    == gestureFrameReaders[index].VisualGestureBuilderFrameSource.TrackingId)
                {
                    return index;
                }
            }
            return -1;
        }
        void UpdateBodyFrame()
        {
            if (bodyFrameReader == null)
            {
                return;
            }
            BodyFrame bodyFrame;
            bodyFrame = bodyFrameReader.AcquireLatestFrame();
            if (bodyFrame == null)
            {
                return;
            }
            bodyFrame.GetAndRefreshBodyData(bodies);
            for (int count = 0; count < BODY_COUNT; count++)
            {
                Body body = bodies[count];
                bool tracked = body.IsTracked;
                if (!tracked)
                {
                    continue;
                }
                ulong trackingId = body.TrackingId;
                VisualGestureBuilderFrameSource gestureFrameSource;
                gestureFrameSource = gestureFrameReaders[count].VisualGestureBuilderFrameSource;
                gestureFrameSource.TrackingId = trackingId;
            }
            bodyFrame.Dispose();
        }
        void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            var reference = e.FrameReference.AcquireFrame();
            using (var frame = reference.BodyFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    canvas.Children.Clear();

                    _bodies = new Body[frame.BodyFrameSource.BodyCount];

                    frame.GetAndRefreshBodyData(_bodies);

                    foreach (var body in _bodies)
                    {
                        if (body != null)
                        {
                            if (body.IsTracked)
                            {
                                // Draw skeleton.
                                if (_displayBody)
                                {
                                    canvas.DrawSkeleton2(body);

                                }
                            }
                        }
                    }

                }
            }
            using (var frame = reference.BodyFrameReference.AcquireFrame())
            {
                if (frame != null)
                {
                    canvas.Children.Clear();

                    _bodies = new Body[frame.BodyFrameSource.BodyCount];

                    frame.GetAndRefreshBodyData(_bodies);

                    foreach (var body in _bodies)
                    {
                        if (body != null)
                        {
                            if (body.IsTracked)
                            {
                                // Draw skeleton.
                                if (_displayBody)
                                {
                                    canvas.DrawSkeleton2(body);

                                }
                            }
                        }
                    }

                }
            }

        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (kinect != null)
            {
                kinect.Close();
                kinect = null;
            }
        }
    }
}