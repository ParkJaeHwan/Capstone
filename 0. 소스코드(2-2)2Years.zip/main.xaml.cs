﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KinectCapstone_Project
{
    public partial class main : Window
    {
        public main()
        {
            InitializeComponent();
        }
        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            dum dum = new dum();
            dum.Show();
            this.Close();
        }
        private void ButtonClicked1(object sender, RoutedEventArgs e)
        {

            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
        private void ButtonClicked2(object sender, RoutedEventArgs e)
        {
            golf golf = new golf();
            golf.Show();
            this.Close();
        }
    }
}
