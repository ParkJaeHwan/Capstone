﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Kinect;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace KinectCapstone_Project
{
    public static class show
    {
        public static Joint ScaleTo(this Joint joint, double width, double height, float skeletonMaxX, float skeletonMaxY, Body body)
        {


            joint.Position = new CameraSpacePoint
            {
                X = Scale(width, skeletonMaxX, joint.Position.X),
                Y = Scale(height, skeletonMaxY, -joint.Position.Y),
                Z = joint.Position.Z

            };
            return joint;

        }

        public static Joint ScaleTo(this Joint joint, double width, double height, Body body)
        {
            return ScaleTo(joint, width, height, 1.0f, 1.0f, body);
        }

        private static float Scale(double maxPixel, double maxSkeleton, float position)
        {
            float value = (float)((((maxPixel / maxSkeleton) / 2) * position) + (maxPixel / 2));

            if (value > maxPixel)
            {
                return (float)maxPixel;
            }

            if (value < 0)
            {
                return 0;
            }

            return value;
        }



        public static void DrawSkeleton(this Canvas canvas, Body body)
        {
            //var main = App.Current.MainWindow as MainWindow;
            dum dum = new KinectCapstone_Project.dum();
            golf golf = new golf();
            MainWindow main = new MainWindow();
            if (body == null) return;

            foreach (Joint joint in body.Joints.Values)
            {
                canvas.DrawPoint(joint, body);
            }
            //dum.Message();
            canvas.DrawLine(body.Joints[JointType.Head], body.Joints[JointType.Neck], body);
            canvas.DrawLine(body.Joints[JointType.Neck], body.Joints[JointType.SpineShoulder], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderLeft], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderRight], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.SpineMid], body);
            canvas.DrawLine(body.Joints[JointType.ShoulderLeft], body.Joints[JointType.ElbowLeft], body);
            canvas.DrawLine(body.Joints[JointType.ShoulderRight], body.Joints[JointType.ElbowRight], body);
            canvas.DrawLine(body.Joints[JointType.ElbowLeft], body.Joints[JointType.WristLeft], body);
            canvas.DrawLine(body.Joints[JointType.ElbowRight], body.Joints[JointType.WristRight], body);
            canvas.DrawLine(body.Joints[JointType.WristLeft], body.Joints[JointType.HandLeft], body);
            canvas.DrawLine(body.Joints[JointType.WristRight], body.Joints[JointType.HandRight], body);
            canvas.DrawLine(body.Joints[JointType.HandLeft], body.Joints[JointType.HandTipLeft], body);
            canvas.DrawLine(body.Joints[JointType.HandRight], body.Joints[JointType.HandTipRight], body);
            canvas.DrawLine(body.Joints[JointType.HandTipLeft], body.Joints[JointType.ThumbLeft], body);
            canvas.DrawLine(body.Joints[JointType.HandTipRight], body.Joints[JointType.ThumbRight], body);
            canvas.DrawLine(body.Joints[JointType.SpineMid], body.Joints[JointType.SpineBase], body);
            canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipLeft], body);
            canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipRight], body);
            canvas.DrawLine(body.Joints[JointType.HipLeft], body.Joints[JointType.KneeLeft], body);
            canvas.DrawLine(body.Joints[JointType.HipRight], body.Joints[JointType.KneeRight], body);
            canvas.DrawLine(body.Joints[JointType.KneeLeft], body.Joints[JointType.AnkleLeft], body);
            canvas.DrawLine(body.Joints[JointType.KneeRight], body.Joints[JointType.AnkleRight], body);
            canvas.DrawLine(body.Joints[JointType.AnkleLeft], body.Joints[JointType.FootLeft], body);
            canvas.DrawLine(body.Joints[JointType.AnkleRight], body.Joints[JointType.FootRight], body);
            if (dum.confidence < 0.06 )
            {
                canvas.DrawLine(body.Joints[JointType.Head], body.Joints[JointType.Neck], body);
                canvas.DrawLine(body.Joints[JointType.Neck], body.Joints[JointType.SpineShoulder], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderLeft], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderRight], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.SpineMid], body);
                canvas.DrawLine1(body.Joints[JointType.ShoulderLeft], body.Joints[JointType.ElbowLeft], body);
                canvas.DrawLine1(body.Joints[JointType.ShoulderRight], body.Joints[JointType.ElbowRight], body);
                canvas.DrawLine1(body.Joints[JointType.ElbowLeft], body.Joints[JointType.WristLeft], body);
                canvas.DrawLine1(body.Joints[JointType.ElbowRight], body.Joints[JointType.WristRight], body);
                canvas.DrawLine1(body.Joints[JointType.WristLeft], body.Joints[JointType.HandLeft], body);
                canvas.DrawLine1(body.Joints[JointType.WristRight], body.Joints[JointType.HandRight], body);
                canvas.DrawLine(body.Joints[JointType.HandLeft], body.Joints[JointType.HandTipLeft], body);
                canvas.DrawLine(body.Joints[JointType.HandRight], body.Joints[JointType.HandTipRight], body);
                canvas.DrawLine(body.Joints[JointType.HandTipLeft], body.Joints[JointType.ThumbLeft], body);
                canvas.DrawLine(body.Joints[JointType.HandTipRight], body.Joints[JointType.ThumbRight], body);
                canvas.DrawLine(body.Joints[JointType.SpineMid], body.Joints[JointType.SpineBase], body);
                canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipLeft], body);
                canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipRight], body);
                canvas.DrawLine(body.Joints[JointType.HipLeft], body.Joints[JointType.KneeLeft], body);
                canvas.DrawLine(body.Joints[JointType.HipRight], body.Joints[JointType.KneeRight], body);
                canvas.DrawLine(body.Joints[JointType.KneeLeft], body.Joints[JointType.AnkleLeft], body);
                canvas.DrawLine(body.Joints[JointType.KneeRight], body.Joints[JointType.AnkleRight], body);
                canvas.DrawLine(body.Joints[JointType.AnkleLeft], body.Joints[JointType.FootLeft], body);
                canvas.DrawLine(body.Joints[JointType.AnkleRight], body.Joints[JointType.FootRight], body);

            }
         
        }
        public static void DrawSkeleton1(this Canvas canvas, Body body)
        {
            //var main = App.Current.MainWindow as MainWindow;
            dum dum = new KinectCapstone_Project.dum();
            golf golf = new golf();
            MainWindow main = new MainWindow();
            if (body == null) return;

            foreach (Joint joint in body.Joints.Values)
            {
                canvas.DrawPoint(joint, body);
            }
            //dum.Message();
            canvas.DrawLine(body.Joints[JointType.Head], body.Joints[JointType.Neck], body);
            canvas.DrawLine(body.Joints[JointType.Neck], body.Joints[JointType.SpineShoulder], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderLeft], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderRight], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.SpineMid], body);
            canvas.DrawLine(body.Joints[JointType.ShoulderLeft], body.Joints[JointType.ElbowLeft], body);
            canvas.DrawLine(body.Joints[JointType.ShoulderRight], body.Joints[JointType.ElbowRight], body);
            canvas.DrawLine(body.Joints[JointType.ElbowLeft], body.Joints[JointType.WristLeft], body);
            canvas.DrawLine(body.Joints[JointType.ElbowRight], body.Joints[JointType.WristRight], body);
            canvas.DrawLine(body.Joints[JointType.WristLeft], body.Joints[JointType.HandLeft], body);
            canvas.DrawLine(body.Joints[JointType.WristRight], body.Joints[JointType.HandRight], body);
            canvas.DrawLine(body.Joints[JointType.HandLeft], body.Joints[JointType.HandTipLeft], body);
            canvas.DrawLine(body.Joints[JointType.HandRight], body.Joints[JointType.HandTipRight], body);
            canvas.DrawLine(body.Joints[JointType.HandTipLeft], body.Joints[JointType.ThumbLeft], body);
            canvas.DrawLine(body.Joints[JointType.HandTipRight], body.Joints[JointType.ThumbRight], body);
            canvas.DrawLine(body.Joints[JointType.SpineMid], body.Joints[JointType.SpineBase], body);
            canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipLeft], body);
            canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipRight], body);
            canvas.DrawLine(body.Joints[JointType.HipLeft], body.Joints[JointType.KneeLeft], body);
            canvas.DrawLine(body.Joints[JointType.HipRight], body.Joints[JointType.KneeRight], body);
            canvas.DrawLine(body.Joints[JointType.KneeLeft], body.Joints[JointType.AnkleLeft], body);
            canvas.DrawLine(body.Joints[JointType.KneeRight], body.Joints[JointType.AnkleRight], body);
            canvas.DrawLine(body.Joints[JointType.AnkleLeft], body.Joints[JointType.FootLeft], body);
            canvas.DrawLine(body.Joints[JointType.AnkleRight], body.Joints[JointType.FootRight], body);
          
            if (MainWindow.confidence < 0.005)
            {
                canvas.DrawLine(body.Joints[JointType.Head], body.Joints[JointType.Neck], body);
                canvas.DrawLine(body.Joints[JointType.Neck], body.Joints[JointType.SpineShoulder], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderLeft], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderRight], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.SpineMid], body);
                canvas.DrawLine(body.Joints[JointType.ShoulderLeft], body.Joints[JointType.ElbowLeft], body);
                canvas.DrawLine(body.Joints[JointType.ShoulderRight], body.Joints[JointType.ElbowRight], body);
                canvas.DrawLine(body.Joints[JointType.ElbowLeft], body.Joints[JointType.WristLeft], body);
                canvas.DrawLine(body.Joints[JointType.ElbowRight], body.Joints[JointType.WristRight], body);
                canvas.DrawLine(body.Joints[JointType.WristLeft], body.Joints[JointType.HandLeft], body);
                canvas.DrawLine(body.Joints[JointType.WristRight], body.Joints[JointType.HandRight], body);
                canvas.DrawLine(body.Joints[JointType.HandLeft], body.Joints[JointType.HandTipLeft], body);
                canvas.DrawLine(body.Joints[JointType.HandRight], body.Joints[JointType.HandTipRight], body);
                canvas.DrawLine(body.Joints[JointType.HandTipLeft], body.Joints[JointType.ThumbLeft], body);
                canvas.DrawLine(body.Joints[JointType.HandTipRight], body.Joints[JointType.ThumbRight], body);
                canvas.DrawLine(body.Joints[JointType.SpineMid], body.Joints[JointType.SpineBase], body);
                canvas.DrawLine1(body.Joints[JointType.SpineBase], body.Joints[JointType.HipLeft], body);
                canvas.DrawLine1(body.Joints[JointType.SpineBase], body.Joints[JointType.HipRight], body);
                canvas.DrawLine1(body.Joints[JointType.HipLeft], body.Joints[JointType.KneeLeft], body);
                canvas.DrawLine1(body.Joints[JointType.HipRight], body.Joints[JointType.KneeRight], body);
                canvas.DrawLine1(body.Joints[JointType.KneeLeft], body.Joints[JointType.AnkleLeft], body);
                canvas.DrawLine1(body.Joints[JointType.KneeRight], body.Joints[JointType.AnkleRight], body);
                canvas.DrawLine(body.Joints[JointType.AnkleLeft], body.Joints[JointType.FootLeft], body);
                canvas.DrawLine(body.Joints[JointType.AnkleRight], body.Joints[JointType.FootRight], body);
            }
        }
        public static void DrawSkeleton2(this Canvas canvas, Body body)
        {
            //var main = App.Current.MainWindow as MainWindow;
            dum dum = new KinectCapstone_Project.dum();
            golf golf = new golf();
            MainWindow main = new MainWindow();
            if (body == null) return;

            foreach (Joint joint in body.Joints.Values)
            {
                canvas.DrawPoint(joint, body);
            }
            //dum.Message();
            canvas.DrawLine(body.Joints[JointType.Head], body.Joints[JointType.Neck], body);
            canvas.DrawLine(body.Joints[JointType.Neck], body.Joints[JointType.SpineShoulder], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderLeft], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderRight], body);
            canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.SpineMid], body);
            canvas.DrawLine(body.Joints[JointType.ShoulderLeft], body.Joints[JointType.ElbowLeft], body);
            canvas.DrawLine(body.Joints[JointType.ShoulderRight], body.Joints[JointType.ElbowRight], body);
            canvas.DrawLine(body.Joints[JointType.ElbowLeft], body.Joints[JointType.WristLeft], body);
            canvas.DrawLine(body.Joints[JointType.ElbowRight], body.Joints[JointType.WristRight], body);
            canvas.DrawLine(body.Joints[JointType.WristLeft], body.Joints[JointType.HandLeft], body);
            canvas.DrawLine(body.Joints[JointType.WristRight], body.Joints[JointType.HandRight], body);
            canvas.DrawLine(body.Joints[JointType.HandLeft], body.Joints[JointType.HandTipLeft], body);
            canvas.DrawLine(body.Joints[JointType.HandRight], body.Joints[JointType.HandTipRight], body);
            canvas.DrawLine(body.Joints[JointType.HandTipLeft], body.Joints[JointType.ThumbLeft], body);
            canvas.DrawLine(body.Joints[JointType.HandTipRight], body.Joints[JointType.ThumbRight], body);
            canvas.DrawLine(body.Joints[JointType.SpineMid], body.Joints[JointType.SpineBase], body);
            canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipLeft], body);
            canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipRight], body);
            canvas.DrawLine(body.Joints[JointType.HipLeft], body.Joints[JointType.KneeLeft], body);
            canvas.DrawLine(body.Joints[JointType.HipRight], body.Joints[JointType.KneeRight], body);
            canvas.DrawLine(body.Joints[JointType.KneeLeft], body.Joints[JointType.AnkleLeft], body);
            canvas.DrawLine(body.Joints[JointType.KneeRight], body.Joints[JointType.AnkleRight], body);
            canvas.DrawLine(body.Joints[JointType.AnkleLeft], body.Joints[JointType.FootLeft], body);
            canvas.DrawLine(body.Joints[JointType.AnkleRight], body.Joints[JointType.FootRight], body);
 
            if (golf.confidence < 0.005)
            {
                canvas.DrawLine(body.Joints[JointType.Head], body.Joints[JointType.Neck], body);
                canvas.DrawLine(body.Joints[JointType.Neck], body.Joints[JointType.SpineShoulder], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderLeft], body);
                canvas.DrawLine(body.Joints[JointType.SpineShoulder], body.Joints[JointType.ShoulderRight], body);
                canvas.DrawLine1(body.Joints[JointType.SpineShoulder], body.Joints[JointType.SpineMid], body);
                canvas.DrawLine(body.Joints[JointType.ShoulderLeft], body.Joints[JointType.ElbowLeft], body);
                canvas.DrawLine(body.Joints[JointType.ShoulderRight], body.Joints[JointType.ElbowRight], body);
                canvas.DrawLine(body.Joints[JointType.ElbowLeft], body.Joints[JointType.WristLeft], body);
                canvas.DrawLine(body.Joints[JointType.ElbowRight], body.Joints[JointType.WristRight], body);
                canvas.DrawLine(body.Joints[JointType.WristLeft], body.Joints[JointType.HandLeft], body);
                canvas.DrawLine(body.Joints[JointType.WristRight], body.Joints[JointType.HandRight], body);
                canvas.DrawLine(body.Joints[JointType.HandLeft], body.Joints[JointType.HandTipLeft], body);
                canvas.DrawLine(body.Joints[JointType.HandRight], body.Joints[JointType.HandTipRight], body);
                canvas.DrawLine(body.Joints[JointType.HandTipLeft], body.Joints[JointType.ThumbLeft], body);
                canvas.DrawLine(body.Joints[JointType.HandTipRight], body.Joints[JointType.ThumbRight], body);
                canvas.DrawLine1(body.Joints[JointType.SpineMid], body.Joints[JointType.SpineBase], body);
                canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipLeft], body);
                canvas.DrawLine(body.Joints[JointType.SpineBase], body.Joints[JointType.HipRight], body);
                canvas.DrawLine(body.Joints[JointType.HipLeft], body.Joints[JointType.KneeLeft], body);
                canvas.DrawLine(body.Joints[JointType.HipRight], body.Joints[JointType.KneeRight], body);
                canvas.DrawLine(body.Joints[JointType.KneeLeft], body.Joints[JointType.AnkleLeft], body);
                canvas.DrawLine(body.Joints[JointType.KneeRight], body.Joints[JointType.AnkleRight], body);
                canvas.DrawLine(body.Joints[JointType.AnkleLeft], body.Joints[JointType.FootLeft], body);
                canvas.DrawLine(body.Joints[JointType.AnkleRight], body.Joints[JointType.FootRight], body);
            }
        }
        public static void DrawPoint(this Canvas canvas, Joint joint, Body body)
        {
            if (joint.TrackingState == TrackingState.NotTracked) return;

            joint = joint.ScaleTo(canvas.ActualWidth, canvas.ActualHeight, body);

            Ellipse ellipse = new Ellipse
            {
                Width = 10,
                Height = 10,
                Fill = new SolidColorBrush(Colors.Black)
            };

            Canvas.SetLeft(ellipse, joint.Position.X - ellipse.Width / 2);
            Canvas.SetTop(ellipse, joint.Position.Y - ellipse.Height / 2);

            canvas.Children.Add(ellipse);
        }
        public static void DrawPoint1(this Canvas canvas, Joint joint, Body body)
        {
            if (joint.TrackingState == TrackingState.NotTracked) return;

            joint = joint.ScaleTo(canvas.ActualWidth, canvas.ActualHeight, body);

            Ellipse ellipse = new Ellipse
            {
                Width = 10,
                Height = 10,
                Fill = new SolidColorBrush(Colors.Red)
            };

            Canvas.SetLeft(ellipse, joint.Position.X - ellipse.Width / 2);
            Canvas.SetTop(ellipse, joint.Position.Y - ellipse.Height / 2);

            canvas.Children.Add(ellipse);
        }

        public static void DrawLine(this Canvas canvas, Joint first, Joint second, Body body)
        {
            if (first.TrackingState == TrackingState.NotTracked || second.TrackingState == TrackingState.NotTracked) return;

            first = first.ScaleTo(canvas.ActualWidth, canvas.ActualHeight, body);
            second = second.ScaleTo(canvas.ActualWidth, canvas.ActualHeight, body);

            Line line = new Line
            {
                X1 = first.Position.X,
                Y1 = first.Position.Y,
                X2 = second.Position.X,
                Y2 = second.Position.Y,
                StrokeThickness = 8,
                Stroke = new SolidColorBrush(Colors.Black)
            };

            canvas.Children.Add(line);
        }
        public static void DrawLine1(this Canvas canvas, Joint first, Joint second, Body body)
        {
            if (first.TrackingState == TrackingState.NotTracked || second.TrackingState == TrackingState.NotTracked) return;

            first = first.ScaleTo(canvas.ActualWidth, canvas.ActualHeight, body);
            second = second.ScaleTo(canvas.ActualWidth, canvas.ActualHeight, body);

            Line line = new Line
            {
                X1 = first.Position.X,
                Y1 = first.Position.Y,
                X2 = second.Position.X,
                Y2 = second.Position.Y,
                StrokeThickness = 8,
                Stroke = new SolidColorBrush(Colors.Red)
            };

            canvas.Children.Add(line);
        }
    }

}