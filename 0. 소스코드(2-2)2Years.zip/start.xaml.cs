﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace KinectCapstone_Project
{
    public partial class start : Window
    {
        public start()
        {
            InitializeComponent();

            System.Diagnostics.Process ps = new System.Diagnostics.Process();
            ps.StartInfo.FileName = "KinectCapstone_MouseControl.exe";
            ps.StartInfo.WorkingDirectory = "C:\\Users\\jhe-3\\Desktop\\KinectCapstone_MouseControl_8.20ver1";
            ps.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Minimized;
            ps.Start();
        }
        private void ButtonClicked(object sender, RoutedEventArgs e)
        {
            main main = new main();
            main.Show();
            this.Close();
        }
    }
}
